# MyExcel
Simple generator of XLSX files from Javascript

To demo it try [this sample](http://jsegarra1971.github.io/MyExcel/sample.html). Look at its source code. 

It so simple that no documentation is required. Contact me for bugs, requests, ideas,...

Licensed under MIT, but if you use it, I´d appreciate if you let me know.


